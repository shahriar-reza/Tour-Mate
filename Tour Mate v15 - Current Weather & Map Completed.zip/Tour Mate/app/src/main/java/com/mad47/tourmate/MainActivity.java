package com.mad47.tourmate;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.mad47.tourmate.Fragments.AddEventFragment;
import com.mad47.tourmate.Fragments.EditEventFragment;
import com.mad47.tourmate.Fragments.EventDetailsFragment;
import com.mad47.tourmate.Fragments.EventListFragment;
import com.mad47.tourmate.Fragments.EventUnderneathFragment;
import com.mad47.tourmate.Fragments.LoginFragment;
import com.mad47.tourmate.Fragments.RegistrationFragment;
import com.mad47.tourmate.Fragments.WeatherContainerFragment;
import com.mad47.tourmate.Location.MapsActivity;

public class MainActivity extends AppCompatActivity implements LoginFragment.UserLoginListener,
        RegistrationFragment.UserRegListener, LoginFragment.UserRegRequestListener,
        EventListFragment.AddEventListener, AddEventFragment.ShowEventListListener, EventListFragment.ItemClickedListener,
        EventDetailsFragment.OnEditFabClickedListener, EditEventFragment.EventEditCompleteListener {
    private FragmentManager manager;
    private FirebaseAuth auth;
    private FirebaseUser user;

    //private boolean isLoggedIn = false;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    //private LoginPreference preference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //preference = new LoginPreference(this);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(listener);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_menu_);

        manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        LoginFragment loginFragment = new LoginFragment();
        ft.add(R.id.fragmentContainer, loginFragment);
        ft.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem loginItem = menu.findItem(R.id.menu_login);
        MenuItem logoutItem = menu.findItem(R.id.menu_logout);

        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        if(user != null){
            loginItem.setVisible(false);
            logoutItem.setVisible(true);
        }else{
            loginItem.setVisible(true);
            logoutItem.setVisible(false);
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        switch (item.getItemId()){
            case android.R.id.home:
                drawerLayout.openDrawer(GravityCompat.START);
                if (user != null){
                    FragmentTransaction ft = manager.beginTransaction();
                    EventListFragment eventListFragment = new EventListFragment();
                    ft.replace(R.id.fragmentContainer, eventListFragment);
                    ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    ft.commit();
                }else{
                    onLogoutComplete();
                }
                /**/
                return true;
            case R.id.menu_notification:
                //settings
                break;
            case R.id.menu_login:
                onLogoutComplete();
                break;
            case R.id.menu_logout:
                if(user != null){
                    auth.signOut();
                    onLogoutComplete();
                }
                // preference.setLoginStatus(false);
                break;


        }
        return super.onOptionsItemSelected(item);
    }

    NavigationView.OnNavigationItemSelectedListener listener =
            new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    item.setChecked(true);
                    // close drawer when item is tapped
                    switch (item.getItemId()){
                        case R.id.weather_update:
                            FragmentTransaction ft = manager.beginTransaction();
                            WeatherContainerFragment weatherContainerFragment = new WeatherContainerFragment();
                            ft.replace(R.id.fragmentContainer, weatherContainerFragment);
                            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                            ft.commit();
                            ft.addToBackStack(null);
                            break;

                        case R.id.location_map:
                            startActivity(new Intent(MainActivity.this, MapsActivity.class));
                            break;
                    }
                    drawerLayout.closeDrawers();
                    return true;
                }
            };

    @Override
    public void onLoginComplete() {
        FragmentTransaction ft = manager.beginTransaction();
        EventListFragment eventListFragment = new EventListFragment();
        ft.replace(R.id.fragmentContainer, eventListFragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();
    }

    public void onLogoutComplete(){
        FragmentTransaction ft = manager.beginTransaction();
        LoginFragment loginFragment = new LoginFragment ();
        ft.replace(R.id.fragmentContainer, loginFragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();
    }

    @Override
    public void onRegComplete() {
        FragmentTransaction ft = manager.beginTransaction();
        EventListFragment eventListFragment = new EventListFragment();
        ft.replace(R.id.fragmentContainer, eventListFragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();
    }

    @Override
    public void onRegRequest() {
        FragmentTransaction ft = manager.beginTransaction();
        RegistrationFragment registrationFragment = new RegistrationFragment();
        ft.replace(R.id.fragmentContainer, registrationFragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();
        ft.addToBackStack(null);
    }

    @Override
    public void onFabClicked() {
        FragmentTransaction ft = manager.beginTransaction();
        AddEventFragment addEventFragment = new AddEventFragment();
        ft.replace(R.id.fragmentContainer, addEventFragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();
        ft.addToBackStack(null);
    }

    @Override
    public void onAddEventFinished() {
        FragmentTransaction ft = manager.beginTransaction();
        EventListFragment eventListFragment = new EventListFragment();
        ft.replace(R.id.fragmentContainer, eventListFragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();
    }

    @Override
    public void itemClicked(String rowId) {
        FragmentTransaction ft = manager.beginTransaction();
        EventUnderneathFragment eventUnderneathFragment = new EventUnderneathFragment();
        Bundle bundle = new Bundle ();
        bundle.putString ("rowID", rowId);
        eventUnderneathFragment.setArguments (bundle);
        ft.replace(R.id.fragmentContainer, eventUnderneathFragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.addToBackStack(null);
        ft.commit();

    }

    @Override
    public void onEditEventFabClicked(String eventID) {
        FragmentTransaction ft = manager.beginTransaction();
        EditEventFragment editEventFragment = new EditEventFragment();
        Bundle bundle = new Bundle ();
        bundle.putString ("eventID", eventID);
        editEventFragment.setArguments (bundle);
        ft.replace(R.id.fragmentContainer, editEventFragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();
        ft.addToBackStack(null);
    }

    @Override
    public void onEventEditComplete(String eventID) {
        FragmentTransaction ft = manager.beginTransaction();
        EventUnderneathFragment eventUnderneathFragment = new EventUnderneathFragment();
        Bundle bundle = new Bundle ();
        bundle.putString ("rowID", eventID);
        eventUnderneathFragment.setArguments (bundle);
        ft.replace(R.id.fragmentContainer, eventUnderneathFragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();
    }
}
