package com.mad47.tourmate.Fragments;


import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mad47.tourmate.PojoClasses.Event;
import com.mad47.tourmate.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class EventDetailsFragment extends Fragment {
    private TextView eventNameTV, budgetTV, startDateTV, finishDateTV, destinationTV, startLocTV;
    private FloatingActionButton editFab;
    private Context context;
    private FirebaseAuth auth;
    private FirebaseUser user;
    private DatabaseReference rootRef;
    private DatabaseReference userRef;
    private DatabaseReference eventRef;
    Bundle bundle = new Bundle ();
    Event event;
    private OnEditFabClickedListener onEditFabClickedListener;


    public EventDetailsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
        onEditFabClickedListener = (OnEditFabClickedListener) context;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_event_details, container, false);
        eventNameTV = view.findViewById(R.id.eventNameOutputTV);
        budgetTV = view.findViewById(R.id.budgetAmountOutputTV);
        startDateTV = view.findViewById(R.id.startDateOutputTV);
        finishDateTV = view.findViewById(R.id.finishDateOutputTV);
        destinationTV = view.findViewById(R.id.destinationOutputTV);
        startLocTV = view.findViewById(R.id.startLocationOutputTV);

        editFab = view.findViewById(R.id.fab_edit_event);
        editFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String eventID = getArguments ().getString ("eventID");
                onEditFabClickedListener.onEditEventFabClicked(eventID);
            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated (savedInstanceState);

        final String eventID = getArguments ().getString ("eventID");

        rootRef = FirebaseDatabase.getInstance().getReference();
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        userRef = rootRef.child(user.getUid());
        eventRef = userRef.child(eventID);

        eventRef.addListenerForSingleValueEvent (new ValueEventListener () {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                event = dataSnapshot.getValue(Event.class);
                eventNameTV.setText (event.getEventName ());
                budgetTV.setText(String.valueOf(event.getBudget()));
                startDateTV.setText(event.getStartDate());
                finishDateTV.setText(event.getFinishDate());
                destinationTV.setText(event.getDestination());
                startLocTV.setText(event.getStartLocation());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public interface OnEditFabClickedListener{
        void onEditEventFabClicked(String eventID);
    }

    @Override
    public void onResume() {
        super.onResume ();
    }

    @Override
    public void onDestroy() {
        super.onDestroy ();
    }

    @Override
    public void onDetach() {
        super.onDetach ();
    }
}
