package com.mad47.tourmate.PojoClasses;

public class Expense {
    private String expenseAddedDate;
    private String expenseCaption;
    private double expenseAmount;

    public Expense() {
    }

    public Expense(String expenseAddedDate, String expenseCaption, double expenseAmount) {
        this.expenseAddedDate = expenseAddedDate;
        this.expenseCaption = expenseCaption;
        this.expenseAmount = expenseAmount;
    }

    public String getExpenseAddedDate() {
        return expenseAddedDate;
    }

    public void setExpenseAddedDate(String expenseAddedDate) {
        this.expenseAddedDate = expenseAddedDate;
    }

    public String getExpenseCaption() {
        return expenseCaption;
    }

    public void setExpenseCaption(String expenseCaption) {
        this.expenseCaption = expenseCaption;
    }

    public double getExpenseAmount() {
        return expenseAmount;
    }

    public void setExpenseAmount(double expenseAmount) {
        this.expenseAmount = expenseAmount;
    }
}
