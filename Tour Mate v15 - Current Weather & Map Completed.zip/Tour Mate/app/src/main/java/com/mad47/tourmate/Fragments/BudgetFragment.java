package com.mad47.tourmate.Fragments;


import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mad47.tourmate.Adapters.BudgetAdapter;
import com.mad47.tourmate.Adapters.EventAdapter;
import com.mad47.tourmate.PojoClasses.Budget;
import com.mad47.tourmate.PojoClasses.Event;
import com.mad47.tourmate.R;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class BudgetFragment extends Fragment {
    private TextView budgetAmountTV;
    private FloatingActionButton addBudgetFab;
    private FirebaseAuth auth;
    private FirebaseUser user;
    private DatabaseReference rootRef;
    private DatabaseReference userRef;
    private DatabaseReference eventRef;

    Bundle bundle = new Bundle ();
    Event event;

    private Context context;
    private List<Budget> budgetList = new ArrayList<> ();
    private List<Budget> budgets;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private BudgetAdapter budgetAdapter;
    private EditText newlyAddedBudgetET;
    private Calendar calendar;


    public BudgetFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_budget, container, false);
        budgetAmountTV = view.findViewById(R.id.budgetAmountOutputTV);
        addBudgetFab = view.findViewById(R.id.budgetFab);


        recyclerView = view.findViewById(R.id.budgetRV);
        layoutManager = new LinearLayoutManager(context);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        budgetAdapter = new BudgetAdapter(context, budgetList, this);

        addBudgetFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                LayoutInflater inflater = getActivity().getLayoutInflater();
                View view1 = inflater.inflate (R.layout.dialog_add_budget, null);
                newlyAddedBudgetET = view1.findViewById (R.id.newlyAddedBudget);
                builder.setView (view1)
                        .setTitle ("Add Budget")
                        .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Send the positive button event back to the host activity
                                Toast.makeText(getActivity(), "Add", Toast.LENGTH_SHORT).show();
                                final String eventID = getArguments ().getString ("eventID");
                                rootRef = FirebaseDatabase.getInstance().getReference();
                                auth = FirebaseAuth.getInstance();
                                user = auth.getCurrentUser();
                                userRef = rootRef.child(user.getUid());
                                eventRef = userRef.child(eventID);

                                eventRef.addListenerForSingleValueEvent (new ValueEventListener () {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        String budgetAmount;
                                        double budget;

                                        budgetAmount = newlyAddedBudgetET.getText ().toString ();

                                        if(budgetAmount.isEmpty ()){
                                            newlyAddedBudgetET.setError("Please Insert Amount");
                                            newlyAddedBudgetET.requestFocus();
                                            return;
                                        }else {
                                            event = dataSnapshot.getValue(Event.class);
                                            budgets = event.getBudgetList ();
                                            budget = Double.parseDouble(newlyAddedBudgetET.getText().toString());

                                            calendar = Calendar.getInstance();
                                            String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());

                                            Budget budget1 = new Budget(currentDate, budget);
                                            budgets.add(budget1);
                                            event.setBudgetList (budgets);
                                            eventRef.setValue (event);
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });

                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Send the negative button event back to the host activity
                                Toast.makeText(getActivity(), "Cancel", Toast.LENGTH_SHORT).show();
                            }
                        });
                builder.create();
                builder.show ();
            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        final String eventID = getArguments ().getString ("eventID");
        rootRef = FirebaseDatabase.getInstance().getReference();
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        userRef = rootRef.child(user.getUid());
        eventRef = userRef.child(eventID);

        eventRef.addListenerForSingleValueEvent (new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //budgets.clear ();
                //budgetList.clear ();
                event = dataSnapshot.getValue(Event.class);
                budgetList = event.getBudgetList();
                recyclerView.setAdapter(budgetAdapter);
                double budgetAmount = 0;
                for (int i = 0; i < budgetList.size(); i++){
                    budgetAmount = budgetAmount + budgetList.get(i).getBudgetAmount();
                }
                Toast.makeText (getActivity (), ""+budgetAmount, Toast.LENGTH_SHORT).show ();
                event.setBudget (budgetAmount);
                eventRef.setValue (event);
                budgetAmountTV.setText(String.valueOf(event.getBudget()));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
