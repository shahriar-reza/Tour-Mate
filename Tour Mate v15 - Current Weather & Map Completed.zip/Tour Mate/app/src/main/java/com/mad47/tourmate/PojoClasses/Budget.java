package com.mad47.tourmate.PojoClasses;

public class Budget {
    private String budgetAddedDate;
    private double budgetAmount;

    public Budget() {
    }

    public Budget(String budgetAddedDate, double budgetAmount) {
        this.budgetAddedDate = budgetAddedDate;
        this.budgetAmount = budgetAmount;
    }

    public String getBudgetAddedDate() {
        return budgetAddedDate;
    }

    public void setBudgetAddedDate(String budgetAddedDate) {
        this.budgetAddedDate = budgetAddedDate;
    }

    public double getBudgetAmount() {
        return budgetAmount;
    }

    public void setBudgetAmount(double budgetAmount) {
        this.budgetAmount = budgetAmount;
    }
}
