package com.mad47.tourmate.Fragments;


import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mad47.tourmate.PojoClasses.Budget;
import com.mad47.tourmate.PojoClasses.Event;
import com.mad47.tourmate.PojoClasses.Expense;
import com.mad47.tourmate.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class AddEventFragment extends Fragment {
    private EditText eventNameET, budgetET, destinationET, startLocET;
    private Button startDateBtn, finishDateBtn, addEventBtn;

    private int year, month, dayOfMonth;
    private Calendar calendar;
    String startDate;
    String finishDate;

    private FirebaseAuth auth;
    private FirebaseUser user;
    private DatabaseReference rootRef;
    private DatabaseReference userRef;
    private Context context;
    private ShowEventListListener showEventListListener;

    private List<Event> eventList = new ArrayList<>();
    private List<Budget> budgets = new ArrayList<>();
    private List<Expense> expenses = new ArrayList<>();


    public AddEventFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
        showEventListListener = (ShowEventListListener) context;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        rootRef = FirebaseDatabase.getInstance().getReference();
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        userRef = rootRef.child(user.getUid());

        userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                eventList.clear();
                for(DataSnapshot d: dataSnapshot.getChildren()){
                    Event event = d.getValue(Event.class);
                    eventList.add(event);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_event, container, false);
        eventNameET = view.findViewById(R.id.eventNameInput);
        startDateBtn = view.findViewById(R.id.startDateBtn);
        finishDateBtn = view.findViewById(R.id.finishDateBtn);
        budgetET = view.findViewById(R.id.eventBudgetInput);
        destinationET = view.findViewById(R.id.eventDestinationInput);
        startLocET = view.findViewById(R.id.eventStartLocationInput);
        addEventBtn = view.findViewById(R.id.addEventBtn);

        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        startDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog.OnDateSetListener listener =
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                                SimpleDateFormat sdf = new SimpleDateFormat("E, MMMM dd, yyyy");
                                final Calendar c = Calendar.getInstance();
                                c.set(i, i1, i2);

                                startDate = sdf.format(c.getTime());
                                startDateBtn.setText(startDate);
                            }
                        };
                DatePickerDialog dialog = new DatePickerDialog(getActivity(), listener, year,month,dayOfMonth);
                dialog.show();
            }
        });

        finishDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog.OnDateSetListener listener =
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                                SimpleDateFormat sdf = new SimpleDateFormat("E, MMMM dd, yyyy");
                                final Calendar c = Calendar.getInstance();
                                c.set(i, i1, i2);

                                finishDate = sdf.format(c.getTime());
                                finishDateBtn.setText(finishDate);
                            }
                        };
                DatePickerDialog dialog = new DatePickerDialog(getActivity(), listener, year,month,dayOfMonth);
                dialog.show();
            }
        });

        addEventBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String eventName, destination, startLoc, budgett, startDate, finishDate;
                double budget;

                eventName = eventNameET.getText().toString();
                destination = destinationET.getText().toString();
                startLoc = startLocET.getText().toString();
                budgett = budgetET.getText().toString();
                startDate = startDateBtn.getText().toString();
                finishDate = finishDateBtn.getText().toString();


                if(eventName.isEmpty()){
                    eventNameET.setError("Please Insert Event Name");
                    eventNameET.requestFocus();
                    return;
                }else if(destination.isEmpty()){
                    destinationET.setError("Please Insert Destination");
                    destinationET.requestFocus();
                    return;
                }else if(startLoc.isEmpty()){
                    startLocET.setError("Please Insert Start Location");
                    startLocET.requestFocus();
                    return;
                }else if(budgett.isEmpty()){
                    budgetET.setError("Please Insert Budget");
                    budgetET.requestFocus();
                    return;
                }else if(startDate == null){
                    startDateBtn.setError("Please Select Start Date");
                    startDateBtn.requestFocus();
                    return;
                }else if(finishDate == null){
                    finishDateBtn.setError("Please Select Finish Date");
                    finishDateBtn.requestFocus();
                    return;
                }else {
                    budget = Double.parseDouble(budgetET.getText().toString());

                    calendar = Calendar.getInstance();
                    String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());

                    String keyID = userRef.push().getKey();

                    Budget budget1 = new Budget(currentDate, budget);
                    budgets.add(budget1);

                    Expense expense1 = new Expense (currentDate, "Initial Expense", 0);
                    expenses.add (expense1);

                    Event event = new Event(keyID, eventName, startDate, finishDate, currentDate, budget, destination, startLoc, budgets, expenses);
                    userRef.child(keyID).setValue(event);

                    showEventListListener.onAddEventFinished();
                }
            }
        });

        return view;
    }

    public interface ShowEventListListener{
        void onAddEventFinished();
    }

}
