package com.mad47.tourmate.Fragments;


import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.mad47.tourmate.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class EventUnderneathFragment extends Fragment{
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private Context context;
    Bundle bundle = new Bundle ();


    public EventUnderneathFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_event_underneath, container, false);
        tabLayout = view.findViewById(R.id.tablayout);
        viewPager = view.findViewById(R.id.viewpager);
        String eventID = getArguments ().getString ("rowID");

        bundle.putString ("eventID", eventID);
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.ic_description_black_24dp));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.ic_money));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.ic_money_3));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.ic_collections_moments));
        tabLayout.setSelectedTabIndicatorColor(Color.WHITE);

        TabPagerAdapter adapter = new TabPagerAdapter(getFragmentManager());
        viewPager.setAdapter(adapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        return view;
    }

    private class TabPagerAdapter extends FragmentPagerAdapter {
        public TabPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            switch (position){
                case 0:
                    EventDetailsFragment eventDetailsFragment = new EventDetailsFragment ();
                    eventDetailsFragment.setArguments (bundle);
                    return eventDetailsFragment;

                case 1:
                    BudgetFragment budgetFragment = new BudgetFragment ();
                    budgetFragment.setArguments (bundle);
                    return budgetFragment;

                case 2:
                    ExpenseFragment expenseFragment = new ExpenseFragment();
                    expenseFragment.setArguments (bundle);
                    return expenseFragment;

                case 3:
                    MomentsFragment momentsFragment = new MomentsFragment ();
                    momentsFragment.setArguments (bundle);
                    return momentsFragment;
            }
            return null;
        }

        @Override
        public int getCount() {
            return 4;
        }
    }

}
