package com.mad47.tourmate.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mad47.tourmate.PojoClasses.Expense;
import com.mad47.tourmate.R;

import java.util.List;

public class ExpenseAdapter extends RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder> {
    private Context context;
    private List<Expense> expenseList;

    public ExpenseAdapter(Context context, List<Expense> expenseList, Fragment fragment) {
        this.context = context;
        this.expenseList = expenseList;
    }

    @NonNull
    @Override
    public ExpenseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.expense_rows, parent, false);
        return new ExpenseAdapter.ExpenseViewHolder (v);
    }

    @Override
    public void onBindViewHolder(@NonNull ExpenseViewHolder holder, int position) {
        holder.expenseAddedDateTV.setText(expenseList.get(position).getExpenseAddedDate ());
        holder.expenseAddedCaptionTV.setText(expenseList.get(position).getExpenseCaption ());
        holder.expenseAddedAmountTV.setText(String.valueOf(expenseList.get(position).getExpenseAmount ()));
    }

    @Override
    public int getItemCount() {
        return expenseList.size ();
    }

    public class ExpenseViewHolder extends RecyclerView.ViewHolder {
        TextView expenseAddedDateTV, expenseAddedCaptionTV, expenseAddedAmountTV;
        public ExpenseViewHolder(@NonNull View itemView) {
            super (itemView);

            expenseAddedDateTV = itemView.findViewById(R.id.row_expense_added_date);
            expenseAddedCaptionTV = itemView.findViewById(R.id.row_expense_caption);
            expenseAddedAmountTV = itemView.findViewById(R.id.row_added_expense_amount);
        }
    }
}
