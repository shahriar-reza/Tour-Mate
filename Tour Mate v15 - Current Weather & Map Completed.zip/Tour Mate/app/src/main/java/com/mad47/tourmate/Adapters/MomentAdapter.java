package com.mad47.tourmate.Adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.mad47.tourmate.PojoClasses.Event;
import com.mad47.tourmate.R;

import java.util.List;

public class MomentAdapter extends RecyclerView.Adapter<MomentAdapter.MomentViewHolder>{
    private Context context;
    private List<Bitmap> imageList;
    private ItemActionListener listener;

    public MomentAdapter(Context context, List<Bitmap>imageList, Fragment fragment){
        this.context = context;
        this.imageList = imageList;
        listener = (ItemActionListener) fragment;
    }

    @NonNull
    @Override
    public MomentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.moment_rows, parent, false);
        return new MomentViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MomentViewHolder holder, final int position) {
        holder.imageView.setImageBitmap(imageList.get(position));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Bitmap bm = imageList.get(position);
                Toast.makeText(context, "Image", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return imageList.size();
    }

    public class MomentViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        public MomentViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.rows_imageView);
        }
    }

    public void updateList(List<Bitmap> bitmaps){
        this.imageList = bitmaps;
        notifyDataSetChanged();
    }

    public interface ItemActionListener {
        void onItemClicked(Bitmap bm);
    }
}
