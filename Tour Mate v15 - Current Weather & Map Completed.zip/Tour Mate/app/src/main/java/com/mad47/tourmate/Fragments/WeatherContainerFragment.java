package com.mad47.tourmate.Fragments;


import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.mad47.tourmate.R;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class WeatherContainerFragment extends Fragment {
    private static final int REQUEST_LOCATION_PERMISSION_CODE = 1;
    private static final String TAG = WeatherContainerFragment.class.getSimpleName();

    private TabLayout tabLayout;
    private ViewPager viewPager;
    // private WeatherPagerAdapter pagerAdapter;
    private List<Fragment> fragmentList = new ArrayList<>();
    private FusedLocationProviderClient providerClient;
    private CurrentWeatherFragment currentFragment;
    private ForecastWeatherFragment forecastFragment;
    private double latitude, longitude;
    private Context context;


    public WeatherContainerFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach (context);
        this.context = context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate (R.layout.fragment_weather_container, container, false);
        tabLayout = view.findViewById (R.id.weatherTabLayout);
        viewPager = view.findViewById (R.id.weatherViewPager);
        tabLayout.addTab (tabLayout.newTab ().setText ("Current"));
        tabLayout.addTab (tabLayout.newTab ().setText ("Forecast"));
        tabLayout.setSelectedTabIndicatorColor (Color.WHITE);

        currentFragment = new CurrentWeatherFragment();
        forecastFragment = new ForecastWeatherFragment();
        fragmentList.add(currentFragment);
        fragmentList.add(forecastFragment);

        providerClient = LocationServices.getFusedLocationProviderClient(getActivity());

        if(checkLocationPermission()){
            getDeviceLastLocation();
        }

        TabPagerAdapter adapter = new TabPagerAdapter (getFragmentManager ());
        viewPager.setAdapter (adapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


        return view;
    }

    private void getDeviceLastLocation() {

        if(checkLocationPermission()){
            providerClient.getLastLocation()
                    .addOnSuccessListener(new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            if(location == null){
                                return;
                            }

                            latitude = location.getLatitude();
                            longitude = location.getLongitude();

                            currentFragment.setLatLng(latitude, longitude);
                            //forecastFragment.setLatLng(latitude, longitude);

                        }
                    });
        }
    }

    private boolean checkLocationPermission() {
        if(ActivityCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_LOCATION_PERMISSION_CODE);
            return false;
        }

        return true;
    }

    private class TabPagerAdapter extends FragmentPagerAdapter {
        public TabPagerAdapter(FragmentManager fm) {
            super (fm);
        }

        @Override
        public Fragment getItem(int position)   {
            return fragmentList.get(position);
        }



        @Override
        public int getCount() {
            return fragmentList.size();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == REQUEST_LOCATION_PERMISSION_CODE &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED){
            getDeviceLastLocation();
        }
    }
}
