package com.mad47.tourmate.Fragments;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.mad47.tourmate.MainActivity;
import com.mad47.tourmate.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class LoginFragment extends Fragment {
    private EditText emailET, passwordET;
    private Button loginBtn;
    private TextView regLink;
    private FirebaseAuth auth;
    private FirebaseUser firebaseUser;
    private Context context;
    private UserLoginListener authListener;
    private UserRegRequestListener regRequestListener;


    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
        authListener = (UserLoginListener) context;
        regRequestListener = (UserRegRequestListener) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_login, container, false);
        emailET = view.findViewById(R.id.emailInputLogin);
        passwordET = view.findViewById(R.id.passwordInputLogin);
        loginBtn = view.findViewById(R.id.loginBtn);
        regLink = view.findViewById(R.id.registerLink);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailET.getText().toString();
                String password = passwordET.getText().toString();
                if(email.isEmpty()){
                    emailET.setError("Please Insert Your Email");
                    emailET.requestFocus();
                    return;
                }
                if(password.isEmpty()){
                    passwordET.setError("Please Insert Your Password");
                    passwordET.requestFocus();
                    return;
                }
                auth.signInWithEmailAndPassword(email,password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()){
                                    firebaseUser = auth.getCurrentUser();
                                    Toast.makeText(getActivity(), "Login Successful ", Toast.LENGTH_SHORT).show();
                                    authListener.onLoginComplete();
                                }
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        regLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                regRequestListener.onRegRequest();
            }
        });
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        auth = FirebaseAuth.getInstance();
        firebaseUser = auth.getCurrentUser();
        if (firebaseUser != null){
            authListener.onLoginComplete();
        }
    }

    public interface UserLoginListener{
        void onLoginComplete();
    }

    public interface UserRegRequestListener{
        void onRegRequest();
    }
}
