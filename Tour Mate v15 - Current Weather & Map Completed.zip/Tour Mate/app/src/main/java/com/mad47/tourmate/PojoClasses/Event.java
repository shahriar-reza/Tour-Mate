package com.mad47.tourmate.PojoClasses;

import java.util.List;

public class Event {
    private String eventID;
    private String eventName;
    private String startDate;
    private String finishDate;
    private String eventCreateDate;
    private double budget;
    private String destination;
    private String startLocation;

    private List<Budget> budgetList;
    private List<Expense> expenseList;

    public Event() {
    }

    public Event(String eventID, String eventName, String startDate, String finishDate, String eventCreateDate, double budget, String destination, String startLocation, List<Budget> budgetList, List<Expense> expenseList) {
        this.eventID = eventID;
        this.eventName = eventName;
        this.startDate = startDate;
        this.finishDate = finishDate;
        this.eventCreateDate = eventCreateDate;
        this.budget = budget;
        this.destination = destination;
        this.startLocation = startLocation;
        this.budgetList = budgetList;
        this.expenseList = expenseList;
    }

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(String finishDate) {
        this.finishDate = finishDate;
    }

    public String getEventCreateDate() {
        return eventCreateDate;
    }

    public void setEventCreateDate(String eventCreateDate) {
        this.eventCreateDate = eventCreateDate;
    }

    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getStartLocation() {
        return startLocation;
    }

    public void setStartLocation(String startLocation) {
        this.startLocation = startLocation;
    }

    public List<Budget> getBudgetList() {
        return budgetList;
    }

    public void setBudgetList(List<Budget> budgetList) {
        this.budgetList = budgetList;
    }

    public List<Expense> getExpenseList() {
        return expenseList;
    }

    public void setExpenseList(List<Expense> expenseList) {
        this.expenseList = expenseList;
    }
}
