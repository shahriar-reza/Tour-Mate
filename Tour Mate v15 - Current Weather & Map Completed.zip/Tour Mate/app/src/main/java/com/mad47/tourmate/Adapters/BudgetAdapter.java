package com.mad47.tourmate.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mad47.tourmate.PojoClasses.Budget;
import com.mad47.tourmate.R;

import java.util.List;

public class BudgetAdapter extends RecyclerView.Adapter<BudgetAdapter.BudgetViewHolder>{
    private Context context;
    private List<Budget> budgetList;
    private EventAdapter.ItemActionListener listener;

    public BudgetAdapter(Context context, List<Budget> budgetList, Fragment fragment) {
        this.context = context;
        this.budgetList = budgetList;
    }

    @NonNull
    @Override
    public BudgetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.budget_rows, parent, false);
        return new BudgetAdapter.BudgetViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull BudgetViewHolder holder, int position) {
        holder.addedDateTV.setText(budgetList.get(position).getBudgetAddedDate());
        holder.addedAmountTV.setText(String.valueOf(budgetList.get(position).getBudgetAmount()));
    }

    @Override
    public int getItemCount() {
        return budgetList.size();
    }

    public class BudgetViewHolder extends RecyclerView.ViewHolder {
        TextView addedDateTV, addedAmountTV;
        public BudgetViewHolder(@NonNull View itemView) {
            super(itemView);

            addedDateTV = (TextView)itemView.findViewById(R.id.row_budget_added_date);
            addedAmountTV = (TextView)itemView.findViewById(R.id.row_added_budget_amount);
        }
    }
}
