package com.mad47.tourmate.Fragments;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mad47.tourmate.PojoClasses.CurrentWeather.CurrentWeatherResponse;
import com.mad47.tourmate.PojoClasses.CurrentWeather.RetrofitClient;
import com.mad47.tourmate.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class CurrentWeatherFragment extends Fragment {

    private static final String TAG = CurrentWeatherFragment.class.getSimpleName();
    private TextView cityTV, tempTV, typeTV, maxTV, minTV, pressureTV, humidityTV, windTV, sunriseTV, sunsetTV;
    private String unit = "metric";
    private ImageView iconIV;
    private Context context;

    public CurrentWeatherFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //Log.e(TAG, "onCreateView");
        View view = inflater.inflate(R.layout.fragment_current_weather, container, false);
        cityTV = view.findViewById(R.id.weatherLocationTV);
        tempTV = view.findViewById(R.id.weatherTempTV);
        typeTV = view.findViewById(R.id.weatherTypeTV);
        maxTV = view.findViewById(R.id.weathermaxTV);
        minTV = view.findViewById(R.id.weatherminTV);
        pressureTV = view.findViewById(R.id.weatherPressureTV);
        humidityTV = view.findViewById(R.id.weatherHumidityTV);
        windTV = view.findViewById(R.id.weatherWindTV);
        sunriseTV = view.findViewById(R.id.weatherSunriseTV);
        sunsetTV = view.findViewById(R.id.weatherSunsetTV);
        //iconIV = view.findViewById(R.id.weatherLogoIV);
        return view;
    }

    public void setLatLng(double lat, double lng){
        //tempTV.setText(String.valueOf(lat)+", "+String.valueOf(lng));
        getCurrentWeatherData(lat, lng);

    }

    private void getCurrentWeatherData(double lat, double lng) {

        String api = "6e90a77323a033f4a41810a637db8017";
        String endUrl = String.format("weather?lat=%f&lon=%f&units=%s&appid=%s",lat, lng, unit, api);
        RetrofitClient.getService().getCurrentWeatherResponse(endUrl)
                .enqueue(new Callback<CurrentWeatherResponse>() {
                    @Override
                    public void onResponse(Call<CurrentWeatherResponse> call, Response<CurrentWeatherResponse> response) {
                        if(response.isSuccessful()){
                            CurrentWeatherResponse currentWeatherResponse =
                                    response.body();
                            double temp = currentWeatherResponse.getMain().getTemp();
                            String city = currentWeatherResponse.getName();
                            double max = currentWeatherResponse.getMain().getTempMax();
                            double min = currentWeatherResponse.getMain().getTempMin();
                            double pressure = currentWeatherResponse.getMain().getPressure();
                            int humidity = currentWeatherResponse.getMain().getHumidity();
                            double wind = currentWeatherResponse.getWind().getSpeed();
                            int sunrise = currentWeatherResponse.getSys().getSunrise();
                            int sunset = currentWeatherResponse.getSys().getSunset();
                            //String country = currentWeatherResponse.getSys().getCountry();
                            String description = currentWeatherResponse.getWeather().get(0)
                                    .getDescription();
                            /*String icon = currentWeatherResponse.getWeather().get(0)
                                    .getIcon();
                            Picasso.get()
                                    .load(RetrofitClient.ICON_URL+icon+".png")
                                    .into(iconIV);*/
                            tempTV.setText(String.valueOf(temp)+" ºC");
                            cityTV.setText(city);
                            typeTV.setText(description);
                            maxTV.setText(String.valueOf(max)+"ºC");
                            minTV.setText(String.valueOf(min)+"ºC");
                            pressureTV.setText(String.valueOf(pressure));
                            humidityTV.setText(String.valueOf(humidity));
                            windTV.setText(String.valueOf(wind));
                            sunriseTV.setText(String.valueOf(sunrise));
                            sunsetTV.setText(String.valueOf(sunset));



                        }
                    }

                    @Override
                    public void onFailure(Call<CurrentWeatherResponse> call, Throwable t) {
                        Log.e(TAG, "onFailure: "+t.getMessage());
                    }
                });
    }


}
