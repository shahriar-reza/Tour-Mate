package com.mad47.tourmate.Fragments;


import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mad47.tourmate.Adapters.BudgetAdapter;
import com.mad47.tourmate.Adapters.ExpenseAdapter;
import com.mad47.tourmate.PojoClasses.Budget;
import com.mad47.tourmate.PojoClasses.Event;
import com.mad47.tourmate.PojoClasses.Expense;
import com.mad47.tourmate.R;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class ExpenseFragment extends Fragment {
    private TextView budgetAmountTV, expenseAmountTV;
    private FloatingActionButton addExpenseFab;
    private FirebaseAuth auth;
    private FirebaseUser user;
    private DatabaseReference rootRef;
    private DatabaseReference userRef;
    private DatabaseReference eventRef;

    Bundle bundle = new Bundle ();
    Event event;

    private Context context;
    private List<Expense> expenseList = new ArrayList<> ();
    private List<Expense> expenses;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private ExpenseAdapter expenseAdapter;
    private TextView newlyAddedExpenseDateTV;
    private EditText newlyAddedExpenseAmountET, newlyAddedExpenseCaptionET;
    private Calendar calendar;

    public ExpenseFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach (context);
        this.context = context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_expense, container, false);

        budgetAmountTV = view.findViewById (R.id.budgetedAmountOutputTV);
        expenseAmountTV = view.findViewById (R.id.expenseAmountOutputTV);
        addExpenseFab = view.findViewById(R.id.expenseFab);

        recyclerView = view.findViewById(R.id.budgetRV);
        layoutManager = new LinearLayoutManager(context);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        expenseAdapter = new ExpenseAdapter (context, expenseList, this);

        addExpenseFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                LayoutInflater inflater = getActivity().getLayoutInflater();

                View view1 = inflater.inflate (R.layout.dialog_add_expense, null);
               // newlyAddedExpenseDateTV = view1.findViewById (R.id.newlyAddedExpenseDate);
                newlyAddedExpenseCaptionET = view1.findViewById (R.id.newlyAddedExpenseCaption);
                newlyAddedExpenseAmountET = view1.findViewById (R.id.newlyAddedExpenseAmount);

                builder.setView (view1)
                        .setTitle ("Add Expense")
                        .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Send the positive button event back to the host activity
                                final String eventID = getArguments ().getString ("eventID");
                                rootRef = FirebaseDatabase.getInstance().getReference();
                                auth = FirebaseAuth.getInstance();
                                user = auth.getCurrentUser();
                                userRef = rootRef.child(user.getUid());
                                eventRef = userRef.child(eventID);

                                eventRef.addListenerForSingleValueEvent (new ValueEventListener () {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        String expenseAmount, expenseCaption;
                                        double exAmount;
                                        String exCaption;

                                        expenseAmount = newlyAddedExpenseAmountET.getText ().toString ();
                                        expenseCaption = newlyAddedExpenseCaptionET.getText ().toString ();

                                        if(expenseAmount.isEmpty ()){
                                            newlyAddedExpenseAmountET.setError("Please Insert Amount");
                                            newlyAddedExpenseAmountET.requestFocus();
                                            return;
                                        }else if(expenseCaption.isEmpty ()){
                                            newlyAddedExpenseCaptionET.setError("Please Insert Caption");
                                            newlyAddedExpenseCaptionET.requestFocus();
                                            return;
                                        }else {
                                            event = dataSnapshot.getValue(Event.class);
                                            expenses = event.getExpenseList ();
                                            exAmount = Double.parseDouble(newlyAddedExpenseAmountET.getText().toString());
                                            exCaption = newlyAddedExpenseCaptionET.getText ().toString ();

                                            calendar = Calendar.getInstance();
                                            String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());

                                            double exp = 0, bud;
                                            for (int i = 0; i < expenses.size (); i++){
                                                exp = exp + expenses.get (i).getExpenseAmount ();
                                            }
                                            bud = event.getBudget ();
                                            if(exp+exAmount < bud){
                                                Expense expense1 = new Expense (currentDate, exCaption, exAmount);
                                                expenses.add(expense1);
                                                event.setExpenseList (expenses);
                                                eventRef.setValue (event);
                                                Toast.makeText (getActivity (), "Expense Added", Toast.LENGTH_SHORT).show ();
                                            }else {
                                                Toast.makeText (getActivity (), "You can not spend more money! Your budget is not sufficient!", Toast.LENGTH_SHORT).show ();
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });

                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Send the negative button event back to the host activity
                                Toast.makeText(getActivity(), "Canceled", Toast.LENGTH_SHORT).show();
                            }
                        });
                builder.create();
                builder.show ();
            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated (savedInstanceState);

        final String eventID = getArguments ().getString ("eventID");
        rootRef = FirebaseDatabase.getInstance().getReference();
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        userRef = rootRef.child(user.getUid());
        eventRef = userRef.child(eventID);

        eventRef.addListenerForSingleValueEvent (new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //budgets.clear ();
                //budgetList.clear ();
                event = dataSnapshot.getValue(Event.class);
                expenseList = event.getExpenseList ();
                recyclerView.setAdapter(expenseAdapter);
                double expenseAmount = 0;
                for (int i = 0; i < expenseList.size(); i++){
                    expenseAmount = expenseAmount + expenseList.get(i).getExpenseAmount ();
                }
                // Toast.makeText (getActivity (), ""+expenseAmount, Toast.LENGTH_SHORT).show ();
                eventRef.setValue (event);
                budgetAmountTV.setText(String.valueOf(event.getBudget()));
                expenseAmountTV.setText(String.valueOf(expenseAmount));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
