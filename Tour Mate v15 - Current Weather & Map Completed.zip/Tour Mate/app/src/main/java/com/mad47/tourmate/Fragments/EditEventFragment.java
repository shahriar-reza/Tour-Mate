package com.mad47.tourmate.Fragments;


import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mad47.tourmate.PojoClasses.Event;
import com.mad47.tourmate.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * A simple {@link Fragment} subclass.
 */
public class EditEventFragment extends Fragment {
    private EditText eventNameET, budgetET, destinationET, startLocET;
    private Button startDateBtn, finishDateBtn;
    private FloatingActionButton updateFabBtn;
    private Context context;
    private FirebaseAuth auth;
    private FirebaseUser user;
    private DatabaseReference rootRef;
    private DatabaseReference userRef;
    private DatabaseReference eventRef;
    Bundle bundle = new Bundle ();

    private int year, month, dayOfMonth;
    private Calendar calendar;
    String startD;
    String finishD;

    private EventEditCompleteListener eventEditCompleteListener;


    public EditEventFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach (context);
        this.context = context;
        eventEditCompleteListener = (EventEditCompleteListener) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_edit_event, container, false);
        eventNameET = view.findViewById(R.id.eventNameEdit);
        startDateBtn = view.findViewById(R.id.startDateEditBtn);
        finishDateBtn = view.findViewById(R.id.finishDateEditBtn);
        budgetET = view.findViewById(R.id.eventBudgetEdit);
        destinationET = view.findViewById(R.id.eventDestinationEdit);
        startLocET = view.findViewById(R.id.eventStartLocationEdit);
        updateFabBtn = view.findViewById(R.id.updateFab);

        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        startDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog.OnDateSetListener listener =
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                                SimpleDateFormat sdf = new SimpleDateFormat("E, MMMM dd, yyyy");
                                final Calendar c = Calendar.getInstance();
                                c.set(i, i1, i2);

                                startD = sdf.format(c.getTime());
                                startDateBtn.setText(startD);
                            }
                        };
                DatePickerDialog dialog = new DatePickerDialog(getActivity(), listener, year,month,dayOfMonth);
                dialog.show();
            }
        });

        finishDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog.OnDateSetListener listener =
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                                SimpleDateFormat sdf = new SimpleDateFormat("E, MMMM dd, yyyy");
                                final Calendar c = Calendar.getInstance();
                                c.set(i, i1, i2);

                                finishD = sdf.format(c.getTime());
                                finishDateBtn.setText(finishD);
                            }
                        };
                DatePickerDialog dialog = new DatePickerDialog(getActivity(), listener, year,month,dayOfMonth);
                dialog.show();
            }
        });

        updateFabBtn.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                final String eventID = getArguments ().getString ("eventID");

                rootRef = FirebaseDatabase.getInstance().getReference();
                auth = FirebaseAuth.getInstance();
                user = auth.getCurrentUser();
                userRef = rootRef.child(user.getUid());
                eventRef = userRef.child(eventID);



                eventRef.addListenerForSingleValueEvent (new ValueEventListener () {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Event event;
                        event = dataSnapshot.getValue(Event.class);

                        String eventName;
                        Double budgetAmount;
                        String destinationLoc;
                        String startLoc;
                        String startdate, finishdate;

                        eventName = eventNameET.getText ().toString ();
                        if (budgetET.getText ().toString ().isEmpty()){
                            budgetAmount = 0.0;
                        } else{
                            budgetAmount = Double.parseDouble (budgetET.getText ().toString ());
                        }
                        destinationLoc = destinationET.getText ().toString ();
                        startLoc = startLocET.getText ().toString ();
                        startdate = startDateBtn.getText ().toString ();
                        finishdate = finishDateBtn.getText ().toString ();

                        if(eventName.isEmpty()){
                            eventNameET.setError("Please fill up the field correctly");
                            eventNameET.requestFocus();
                            return;
                        } else if(budgetAmount == 0){
                            budgetET.setError("Please fill up the field correctly");
                            budgetET.requestFocus();
                            return;
                        } else if(destinationLoc.isEmpty()){
                            destinationET.setError("Please fill up the field correctly");
                            destinationET.requestFocus();
                            return;
                        } else if(startLoc.isEmpty()){
                            startLocET.setError("Please fill up the field correctly");
                            startLocET.requestFocus();
                            return;
                        } else {
                            event.setEventName (eventName);
                            event.setBudget (budgetAmount);
                            event.getBudgetList().get(0).setBudgetAmount(budgetAmount);
                            event.setDestination (destinationLoc);
                            event.setStartLocation (startLoc);
                            if(startD != null){
                                event.setStartDate (startD);
                            } else{
                                event.setStartDate (startdate);
                            }

                            if(finishD != null) {
                                event.setFinishDate (finishD);
                            } else {
                                event.setFinishDate (finishdate);
                            }

                            eventRef.setValue (event);

                            eventEditCompleteListener.onEventEditComplete (eventID);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {

        final String eventID = getArguments ().getString ("eventID");

        rootRef = FirebaseDatabase.getInstance().getReference();
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        userRef = rootRef.child(user.getUid());
        eventRef = userRef.child(eventID);

        eventRef.addListenerForSingleValueEvent (new ValueEventListener () {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Event event;
                event = dataSnapshot.getValue(Event.class);
                eventNameET.setText (event.getEventName ());
                budgetET.setText(String.valueOf(event.getBudget()));
                startDateBtn.setText(event.getStartDate());
                finishDateBtn.setText(event.getFinishDate());
                destinationET.setText(event.getDestination());
                startLocET.setText(event.getStartLocation());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        super.onActivityCreated(savedInstanceState);
    }

    public interface EventEditCompleteListener{
        public void onEventEditComplete(String eventID);
    }
}
