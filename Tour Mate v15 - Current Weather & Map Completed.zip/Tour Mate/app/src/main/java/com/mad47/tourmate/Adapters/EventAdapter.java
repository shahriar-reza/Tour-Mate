package com.mad47.tourmate.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.mad47.tourmate.PojoClasses.Event;
import com.mad47.tourmate.R;

import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder>{
    private Context context;
    private List<Event> eventList;
    private ItemActionListener listener;

    public EventAdapter(Context context, List<Event> eventList, Fragment fragment) {
        this.context = context;
        this.eventList = eventList;
        listener = (ItemActionListener) fragment;
    }

    @NonNull
    @Override
    public EventAdapter.EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.event_rows, parent, false);
        return new EventViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull EventAdapter.EventViewHolder holder, final int position) {
        holder.eventNameTV.setText(eventList.get(position).getEventName());
        holder.startDateTV.setText(eventList.get(position).getStartDate());
        holder.remTimeTV.setText(eventList.get(position).getFinishDate());
        holder.menuTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(context, v);
                MenuInflater inflater = popupMenu.getMenuInflater();
                inflater.inflate(R.menu.event_action_menu, popupMenu.getMenu());
                popupMenu.show();
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        final String id = eventList.get(position).getEventID();
                        switch (item.getItemId()){
                            case R.id.menu_delete:
                                listener.onItemDelete(id);
                                break;
                        }
                        return false;
                    }
                });
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String id = eventList.get(position).getEventID();
                listener.onItemClicked(id);
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    public class EventViewHolder extends RecyclerView.ViewHolder {
        TextView eventNameTV, startDateTV, remTimeTV, menuTV;
        public EventViewHolder(@NonNull View itemView) {
            super(itemView);

            eventNameTV = itemView.findViewById(R.id.row_event_name);
            startDateTV = itemView.findViewById(R.id.row_event_starting_date);
            remTimeTV = itemView.findViewById(R.id.row_event_remaining_time);
            menuTV = itemView.findViewById(R.id.row_event_action);
        }
    }

    public void updateList(List<Event> events){
        this.eventList = events;
        notifyDataSetChanged();
    }

    public interface ItemActionListener {
        void onItemDelete(String rowId);
        void onItemClicked(String rowId);
    }
}
