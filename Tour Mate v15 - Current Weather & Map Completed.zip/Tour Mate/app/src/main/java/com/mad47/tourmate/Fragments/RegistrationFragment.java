package com.mad47.tourmate.Fragments;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.mad47.tourmate.PojoClasses.Event;
import com.mad47.tourmate.PojoClasses.User;
import com.mad47.tourmate.R;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class RegistrationFragment extends Fragment {
    private EditText nameET, emailET, passwordET, phoneET;
    private Button regBtn;
    private FirebaseAuth auth;
    private ProgressBar progressBar;
    private Context context;
    private UserRegListener authListener;

    private List<User> userList = new ArrayList<>();

    public RegistrationFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
        authListener = (UserRegListener) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_registration, container, false);
        nameET = view.findViewById(R.id.nameInputET);
        emailET = view.findViewById(R.id.emailInputET);
        passwordET = view.findViewById(R.id.passwordInputET);
        phoneET = view.findViewById(R.id.phoneInputET);
        regBtn = view.findViewById(R.id.registrationBtn);
        progressBar = view.findViewById(R.id.progrssbar);
        progressBar.setVisibility(View.GONE);

        regBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String name = nameET.getText().toString();
                final String phone = phoneET.getText().toString();
                final String email = emailET.getText().toString();
                String password = passwordET.getText().toString();
                if(name.isEmpty()){
                    nameET.setError("Please Insert Your Name");
                    nameET.requestFocus();
                    return;
                }
                if(email.isEmpty()){
                    emailET.setError("Please Insert Your Email");
                    emailET.requestFocus();
                    return;
                }
                if(password.isEmpty()){
                    passwordET.setError("Please Insert Your Password");
                    passwordET.requestFocus();
                    return;
                }
                if(phone.isEmpty()){
                    phoneET.setError("Please Insert Your Phone");
                    phoneET.requestFocus();
                    return;
                }
                auth.createUserWithEmailAndPassword(email,password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()){
                                    progressBar.setVisibility(View.VISIBLE);
                                    updateUI();

                                    User user_ = new User(name,email,phone);
                                    userList.add(user_);

                                    authListener.onRegComplete();
                                }
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        return view;
    }

    private void updateUI() {
        progressBar.setVisibility(View.GONE);
        Toast.makeText(getActivity(), "Registration Successful. Logged In.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        auth = FirebaseAuth.getInstance();
    }

    public interface UserRegListener{
        void onRegComplete();
    }

}
